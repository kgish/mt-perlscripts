# Movable Type (r) Open Source (C) 2006-2013 Six Apart, Ltd.
# This program is distributed under the terms of the
# GNU General Public License, version 2.
#
# $Id$

package FormattedTextForTinyMCE::L10N::en_us;

use strict;
use warnings;

use base 'FormattedTextForTinyMCE::L10N';
use vars qw( %Lexicon );

%Lexicon = ();

1;

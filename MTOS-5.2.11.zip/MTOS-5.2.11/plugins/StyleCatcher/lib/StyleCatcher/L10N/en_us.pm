# Movable Type (r) Open Source (C) 2005-2013 Six Apart, Ltd.
# This program is distributed under the terms of the
# GNU General Public License, version 2.
#
# $Id$

package StyleCatcher::L10N::en_us;

use strict;

use base 'StyleCatcher::L10N';
use vars qw( %Lexicon );
%Lexicon = ();

1;

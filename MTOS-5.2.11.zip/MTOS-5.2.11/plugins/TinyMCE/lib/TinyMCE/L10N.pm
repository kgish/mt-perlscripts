# Movable Type (r) Open Source (C) 2005-2013 Six Apart, Ltd.
# This program is distributed under the terms of the
# GNU General Public License, version 2.
#
# $Id$

package TinyMCE::L10N;
use strict;
use base 'MT::Plugin::L10N';

1;
